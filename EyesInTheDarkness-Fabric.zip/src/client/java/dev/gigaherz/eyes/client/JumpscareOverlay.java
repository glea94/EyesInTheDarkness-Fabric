package dev.gigaherz.eyes.client;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.*;
import com.mojang.serialization.Codec;
import dev.gigaherz.eyes.EyesInTheDarkness;
import dev.gigaherz.eyes.config.ConfigData;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import org.joml.Matrix3x2f;

import org.jetbrains.annotations.Nullable;

public class JumpscareOverlay implements HudElement
{
    private static final Identifier TEXTURE_EYES = EyesInTheDarkness.location("textures/entity/eyes2.png");
    private static final Identifier TEXTURE_FLASH = EyesInTheDarkness.location("textures/creepy.png");

    public static JumpscareOverlay INSTANCE = new JumpscareOverlay();

    private static final Rect2i[] FRAMES = {
            new Rect2i(0, 0, 13, 6),
            new Rect2i(0, 7, 13, 6),
            new Rect2i(0, 14, 13, 6),
            new Rect2i(0, 21, 13, 6),
            new Rect2i(15, 1, 15, 8),
            new Rect2i(15, 16, 15, 12),
    };
    private static final int ANIMATION_APPEAR = 10;
    private static final int ANIMATION_LINGER = 90;
    private static final int ANIMATION_BLINK = 60;
    private static final int ANIMATION_SCARE1 = 20;
    private static final int ANIMATION_FADE = 20;
    private static final int ANIMATION_BLINK_START = ANIMATION_APPEAR + ANIMATION_LINGER;
    private static final int ANIMATION_SCARE_START = ANIMATION_BLINK_START + ANIMATION_BLINK;
    private static final int ANIMATION_FADE_START = ANIMATION_SCARE_START + ANIMATION_SCARE1;
    private static final int ANIMATION_TOTAL = ANIMATION_APPEAR + ANIMATION_LINGER + ANIMATION_BLINK
            + ANIMATION_SCARE1 + ANIMATION_FADE;

    public static void register()
    {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CHAT, EyesInTheDarkness.location("jumpscare"), INSTANCE);
        ClientTickEvents.START_CLIENT_TICK.register(client -> INSTANCE.clientTick());
    }

    private boolean visible = false;
    private float progress = 0;

    private JumpscareOverlay()
    {
    }

    public void show(double ex, double ey, double ez)
    {
        if (ConfigData.jumpscareClient)
        {
            visible = true;
            Minecraft.getInstance().level.playLocalSound(ex, ey, ez, EyesInTheDarkness.EYES_JUMPSCARE, SoundSource.HOSTILE, getJumpscareVolume(), 1, false);
        }
    }

    protected float getJumpscareVolume()
    {
        return (float)ConfigData.eyeIdleVolume;
    }

    public void clientTick()
    {
        if (visible)
        {
            progress++;
            if (progress >= ANIMATION_TOTAL)
            {
                visible = false;
                progress = 0;
            }
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, DeltaTracker partialTicks)
    {
        if (!visible) return;

        var mc = Minecraft.getInstance();
        int screenWidth = mc.getWindow().getGuiScaledWidth();
        int screenHeight = mc.getWindow().getGuiScaledHeight();

        float time = progress + partialTicks.getGameTimeDeltaPartialTick(true);
        if (time >= ANIMATION_TOTAL)
        {
            visible = false;
            progress = 0;
            return;
        }

        Matrix3x2f originalPose = new Matrix3x2f(graphics.pose());

        float darkening = Mth.clamp(
                Math.min(
                        time / ANIMATION_APPEAR,
                        (ANIMATION_TOTAL - time) / ANIMATION_FADE
                ), 0, 1
        );

        boolean showCreep = false;
        int blinkstate = 0;
        if (time >= ANIMATION_BLINK_START)
        {
            if (time >= ANIMATION_SCARE_START)
            {
                blinkstate = 1;
                showCreep = true;
            }
            else
            {
                float fade = Math.max(0, (time - ANIMATION_BLINK_START) / ANIMATION_BLINK);
                float blinkspeed = (float) (1 + Math.pow(fade, 3));
                blinkstate = Mth.floor(20 * blinkspeed) & 1;
                showCreep = blinkstate == 1;
            }
        }

        int alpha = Mth.floor(darkening * 255);

        if (alpha > 0)
        {
            graphics.fill(0, 0, screenWidth, screenHeight, alpha << 24);
            if (showCreep)
            {
                int texW = 2048;
                int texH = 1024;

                // CORRECTION PRINCIPALE : Utilisation de la surcharge moderne de blit pour la 1.26.2
                // qui spécifie explicitement la texture sans passer par RenderSystem obsolète.
                // Les paramètres (0, 0, screenWidth, screenHeight) étirent l'image sur tout l'écran.
                graphics.blit(
                        RenderPipelines.GUI_TEXTURED,
                        TEXTURE_FLASH,
                        0,
                        0,
                        0.0f,
                        0.0f,
                        screenWidth,
                        screenHeight,
                        texW,
                        texH,
                        (alpha << 24) | 0xFFFFFF
                );
            }
        }

        if (blinkstate != 1)
        {
            float scale = Float.MAX_VALUE;
            for (Rect2i r : FRAMES)
            {
                float s = Math.min(
                        Mth.floor(screenWidth * 0.8 / (float) r.getWidth()),
                        Mth.floor(screenHeight * 0.8 / (float) r.getHeight()));
                scale = Math.min(scale, s);
            }

            scale = Math.min(1, (1 + time) / (1 + ANIMATION_APPEAR)) * scale;

            int currentFrame = Math.min(FRAMES.length - 1, Mth.floor(FRAMES.length * time / ANIMATION_APPEAR));

            Rect2i rect = FRAMES[currentFrame];
            int tx = rect.getX();
            int ty = rect.getY();
            int tw = rect.getWidth();
            int th = rect.getHeight();

            int drawW = Mth.floor(tw * scale);
            int drawH = Mth.floor(th * scale);
            int drawX = Mth.floor((screenWidth - drawW) / 2.0f);
            int drawY = Mth.floor((screenHeight - drawH) / 2.0f);

            int texW = 32;
            int texH = 32;

            graphics.blit(RenderPipelines.GUI_TEXTURED, TEXTURE_EYES, drawX, drawY, (float)tx, (float)ty, drawW, drawH, texW, texH, 0xFFFFFFFF);
        }

        graphics.pose().set(originalPose);
    }
}
